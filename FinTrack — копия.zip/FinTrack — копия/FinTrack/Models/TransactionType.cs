﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinTrack.Models;

public enum TransactionType
{
    Income,
    Expense
}
